$(document).ready(function() {
	// Ranking

	$('.list ol').sortable();
});